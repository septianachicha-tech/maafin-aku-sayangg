# 💖 Minta Maaf

Halaman interaktif lucu dan manis buat kamu yang mau minta maaf tapi gak tau harus ngomong apa 😭💗  
Bisa buat ke *ayang*, temen, atau bahkan HTS-an kamu hihihi 😆  
Cukup klik, dan biarkan efek *love* yang bekerja~  

---

## ✨ Fitur
- *Personalization* dengan menggunakan nama panggilan
- Tombol "Maafin 💖" dan "Enggak 😠" yang interaktif  
- Efek tombol membesar & mengecil pas ditekan  
- Pop-up love animation super cute  
- Mobile-friendly (bisa dibuka di HP)  
- Kode bersih: HTML, CSS, JS dipisah biar gampang modif  

---

## 💡 Cara Pakai
1. Clone atau fork repo ini:
   ```bash
   git clone https://github.com/alenn-engineer-stress/minta-maaf.git
2. Drag and drop file index.html di browser kamu.
3. Bisa langsung dipakai, atau ubah teks-nya sesuka kamu 😎

---

## 🧑‍💻 Modifikasi Ide

Ubah teksnya sesuai kreativitas kamu

Tambahin foto, animasi, atau efek suara

Ganti warna biar sesuai vibe kamu

Tambahin foto target penerima

---

## 🌐 Live Demo

Kalau mau tampilkan online:

Masuk ke tab Settings → Pages di repo kamu.

Pilih branch main dan folder / (root) → Save.

GitHub bakal kasih link kayak: https://alenn-engineer-stress.github.io/minta-maaf/

---

## Kontribusi

Kalau kamu punya ide kreatif (misal efek pelukan, lagu lucu, atau versi “minta naik gaji ke boss),
boleh banget fork, modif, dan bikin pull request ❤️
